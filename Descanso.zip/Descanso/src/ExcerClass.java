import java.util.Scanner;

public class ExcerClass {

	public static void main(String[] args) {

		Aluno aluno = new Aluno();
		
		System.out.println("Quantas faltas o aluno tem?");
		
		Scanner entrada = new Scanner(System.in);
		aluno.setFaltas(entrada.nextInt());
		aluno.setNome("Jhonata Morais");
		aluno.setMedia1(7);
		aluno.setMedia2(8.5);
		
		System.out.println("O aluno tem " + aluno.getFaltas() + " faltas");
	
		entrada.close();
	}

}
