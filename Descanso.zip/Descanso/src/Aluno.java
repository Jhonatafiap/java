
public class Aluno {

	String nome = "";
	int faltas = 0;
	double media1 = 0;
	double media2 = 0;

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public void setFaltas(int faltas) {
		this.faltas = faltas;
	}

	public void setMedia1(double media1) {
		this.media1 = media1;
	}
	
	public void setMedia2(double media2) {
		this.media2 = media2;
	}

	public String getNome() {
		return this.nome;
	}
	
	public int getFaltas() {
		return this.faltas;
	}

	public double getMedia1() {
		return this.media1;
	}
	
	public double getMedia2() {
		return this.media2;
	}
	
}
